"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileUploadRecordStatus = void 0;
var FileUploadRecordStatus;
(function (FileUploadRecordStatus) {
    FileUploadRecordStatus["PENDING"] = "PENDING";
    FileUploadRecordStatus["UPLOADED"] = "UPLOADED";
    FileUploadRecordStatus["PROCESSING"] = "PROCESSING";
    FileUploadRecordStatus["COMPLETED"] = "COMPLETED";
    FileUploadRecordStatus["FAILED"] = "FAILED";
    FileUploadRecordStatus["EXPIRED"] = "EXPIRED";
})(FileUploadRecordStatus || (exports.FileUploadRecordStatus = FileUploadRecordStatus = {}));
