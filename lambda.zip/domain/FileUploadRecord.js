"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadStatus = void 0;
var UploadStatus;
(function (UploadStatus) {
    UploadStatus["PENDING"] = "PENDING";
    UploadStatus["UPLOADED"] = "UPLOADED";
    UploadStatus["PROCESSING"] = "PROCESSING";
    UploadStatus["COMPLETED"] = "COMPLETED";
    UploadStatus["FAILED"] = "FAILED";
    UploadStatus["EXPIRED"] = "EXPIRED";
})(UploadStatus || (exports.UploadStatus = UploadStatus = {}));
