"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3UploadService = void 0;
var client_s3_1 = require("@aws-sdk/client-s3");
var s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
var uploadValidation_1 = require("../validation/uploadValidation");
var S3UploadService = /** @class */ (function () {
    function S3UploadService(bucketName, region) {
        this.urlExpirationTime = 3600;
        this.bucketName = bucketName || process.env.S3_BUCKET_NAME || 'video-manager-bucket';
        this.s3Client = new client_s3_1.S3Client({
            region: region || process.env.AWS_REGION || 'us-east-1',
        });
    }
    S3UploadService.prototype.validateFile = function (request) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, (0, uploadValidation_1.validateUploadRequest)(request)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    S3UploadService.prototype.generateFileKey = function (request) {
        var timestamp = Date.now();
        var randomSuffix = Math.random().toString(36).substring(2, 15);
        var sanitizedFileName = request.fileName.replace(/[^a-zA-Z0-9.-]/g, '_');
        return "uploads/".concat(request.userId, "/").concat(timestamp, "-").concat(randomSuffix, "-").concat(sanitizedFileName);
    };
    S3UploadService.prototype.generateUploadUrl = function (request) {
        return __awaiter(this, void 0, void 0, function () {
            var fileKey, putObjectCommand, uploadUrl, error_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.validateFile(request)];
                    case 1:
                        _a.sent();
                        fileKey = this.generateFileKey(request);
                        putObjectCommand = new client_s3_1.PutObjectCommand({
                            Bucket: this.bucketName,
                            Key: fileKey,
                            ContentType: request.fileType,
                            Metadata: {
                                userId: request.userId,
                                originalFileName: request.fileName,
                                uploadTimestamp: new Date().toISOString(),
                            },
                        });
                        _a.label = 2;
                    case 2:
                        _a.trys.push([2, 4, , 5]);
                        return [4 /*yield*/, (0, s3_request_presigner_1.getSignedUrl)(this.s3Client, putObjectCommand, {
                                expiresIn: this.urlExpirationTime,
                            })];
                    case 3:
                        uploadUrl = _a.sent();
                        return [2 /*return*/, {
                                uploadUrl: uploadUrl,
                                fileKey: fileKey,
                                expiresIn: this.urlExpirationTime,
                            }];
                    case 4:
                        error_1 = _a.sent();
                        console.error('Error generating upload URL:', error_1);
                        throw new Error('Failed to generate upload URL. Please try again.');
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    S3UploadService.prototype.generateDownloadUrl = function (s3Key, fileName) {
        return __awaiter(this, void 0, void 0, function () {
            var getObjectCommand, downloadUrl, error_2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        getObjectCommand = new client_s3_1.GetObjectCommand({
                            Bucket: this.bucketName,
                            Key: s3Key,
                            ResponseContentDisposition: "attachment; filename=\"".concat(fileName, "\""),
                        });
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, (0, s3_request_presigner_1.getSignedUrl)(this.s3Client, getObjectCommand, {
                                expiresIn: this.urlExpirationTime,
                            })];
                    case 2:
                        downloadUrl = _a.sent();
                        return [2 /*return*/, {
                                downloadUrl: downloadUrl,
                                fileName: fileName,
                                expiresIn: this.urlExpirationTime,
                            }];
                    case 3:
                        error_2 = _a.sent();
                        console.error('Error generating download URL:', error_2);
                        throw new Error('Failed to generate download URL. Please try again.');
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    return S3UploadService;
}());
exports.S3UploadService = S3UploadService;
